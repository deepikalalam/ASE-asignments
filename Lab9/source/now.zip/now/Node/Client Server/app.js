'use strict';

// Declare app level module which depends on views, and components
angular.module('myApp', [])


    .controller('mycontroller', function ($scope, $http) {
        $scope.facepredlist = new Array();

        $scope.getpredictions = function () {
            var imageEntered = document.getElementById("txt_placeName").value;
            if (imageEntered != null && imageEntered != "" ) {
                var collect = $http.get("https://api.clarifai.com/v1/tag?" +
                    "url=" + imageEntered +
                    "&access_token=2X316BY6FYWaT5ekeWn32vsUheWI11");

                collect.success(function (data) {
                    console.log(data);
                    for (var i = 0; i < 3; i++) {
                        $scope.facepredlist[i] = {
                            "name": data.results[0].result.tag.classes[i]

                        };

                    }


                })

                collect.error(function (data) {
                    alert("There was some error processing your request. Please try after some time.");
                });
            }
        }});


      $scope.translate = function (tagsSelected) {
           if (tagsSelected != null) {
        //This is the API call being made to get the spanish translate for the selected tag.
        var handler = $http.get("https://translate.yandex.net/api/v1.5/tr.json/translate?" +
            "key=trnsl.1.1.20151023T145251Z.bf1ca7097253ff7e." +
            "c0b0a88bea31ba51f72504cc0cc42cf891ed90d2&text=" + tagsSelected +"&" +
            "lang=en-es&[format=plain]&[options=1]&[callback=set]+"&outputMode=json&text=" + $scope.spat.text");
        handler.success(function (result) {
            console.log(result);
            $scope.afterTrans = {"afterText": $scope.spat.text}
        }
               handler.error(function (result) {
                   alert("There was some error processing your request. Please try after some time.")
               })
           }
      });








          /*  var placeEntered = document.getElementById("txt_placeName").value;
            var searchQuery = document.getElementById("txt_searchFilter").value;
            if (placeEntered != null && placeEntered != "" && searchQuery != null && searchQuery != "") {
                document.getElementById('div_ReviewList').style.display = 'none';
                //This is the API that gives the list of venues based on the place and search query.
                var handler = $http.get("https://api.foursquare.com/v2/venues/search" +
                    "?client_id=Q0ENF1YHFTNPJ31DCF13ALLENJW0P5MTH13T1SA0ZP1MUOCI" +
                    "&client_secret=ZH4CRZNEWBNTALAE3INIB5XG0QI12R4DT5HKAJLWKYE1LHOG" +
                    "&v=20160215&limit=5" +
                    "&near=" + placeEntered +
                    "&query=" + searchQuery);
                handler.success(function (data) {

                    if (data != null && data.response != null && data.response.venues != undefined && data.response.venues != null) {
                        for (var i = 0; i < data.response.venues.length; i++) {
                            $scope.venueList[i] = {
                                "name": data.response.venues[i].name,
                                "id": data.response.venues[i].id,
                                "location": data.response.venues[i].location
                            };
                        }
                    }

                })
                handler.error(function (data) {
                    alert("There was some error processing your request. Please try after some time.");
                });
            }
        }
        $scope.getReviews = function (venueSelected) {
            if (venueSelected != null) {
                //This is the API call being made to get the reviews(tips) for the selected place or venue.
                var handler = $http.get("https://api.foursquare.com/v2/venues/" + venueSelected.id + "/tips" +
                    "?sort=recent" +
                    "&client_id=Q0ENF1YHFTNPJ31DCF13ALLENJW0P5MTH13T1SA0ZP1MUOCI" +
                    "&client_secret=ZH4CRZNEWBNTALAE3INIB5XG0QI12R4DT5HKAJLWKYE1LHOG&v=20160215" +
                    "&limit=5");
                handler.success(function (result) {
					console.log(result);
                    if (result != null && result.response != null && result.response.tips != null &&
                        result.response.tips.items != null && result.response.tips.count != 0) {
                        $scope.showt=true;
                        $scope.shows=false;
                        $scope.mostRecentReview = result.response.tips.items[0];
						console.log($scope.mostRecentReview);
                        //This is the Alchemy API for getting the sentiment of the most recent review for a place.
                        var callback = $http.get("http://gateway-a.watsonplatform.net/calls/text/TextGetTextSentiment" +
                            "?apikey=d0e7bf68cdda677938e6c186eaf2b755ef737cd8" +
                            "&outputMode=json&text=" + $scope.mostRecentReview.text);
                        callback.success(function (data) {
                            if(data!=null && data.docSentiment!=null)
                            {
                                $scope.ReviewWithSentiment = {"reviewText" : $scope.mostRecentReview.text,
                                                            "sentiment":data.docSentiment.type,
                                                             "score":data.docSentiment.score  };
                                document.getElementById('div_ReviewList').style.display = 'block';
                            }
                        })
                        var translate= $http.get()
                    }
					else
					{
						$scope.showt=false;
                        $scope.shows=true;
                        $scope.noText="No review";
					}
                })
                handler.error(function (result) {
                    alert("There was some error processing your request. Please try after some time.")
                })
            }

        }

    });
    */
