/**
 * @author ry6d3
 *
 */
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
 
@Path("/ctofservice")
public class CtoFService {
	@GET
	@Produces("application/xml")
	public String convertCtoF() {
 
		Double area;
		Double radius = 5.0;
		area = 3.14 * radius * radius;
 
		String result = "@Produces(\"application/xml\") Output: \n\nArea of Cirlce: \n\n" + area;
		return "<areaservice>" + "<radius>" + radius + "</radius>" + "<areaoutput>" + result + "</areaoutput>" + "</areaservice>";
	}
 
	@Path("{c}")
	@GET
	@Produces("application/xml")
	public String convertCtoFfromInput(@PathParam("c") Double c) {
		Double area;
		Double radius = c;
		area = 3.14 * radius * radius;
 
		String result = "@Produces(\"application/xml\") Output: \n\nC to F Converter Output: \n\n" + area;
		return "<areaservice>" + "<radius>" + radius + "</radius>" + "<areaoutput>" + result + "</areaoutput>" + "</areaservice>";
	}
}