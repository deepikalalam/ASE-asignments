public class Calculate1 {

	public int sum(int var1) {
		
		int Area;
		
		Area = (int) (3.14 * var1 * var1);
		System.out.println("circumference of circle " +Area);
		return Area;
	}

}