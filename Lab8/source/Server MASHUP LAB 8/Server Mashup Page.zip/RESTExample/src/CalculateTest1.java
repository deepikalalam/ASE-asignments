import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculateTest1 {

	Calculate1 calculation = new Calculate1();
	int sum = calculation.sum(5);
	int testSum = 78;

	@Test
	public void testSum() {
		System.out.println("@Test sum(): " + sum + " = " + testSum);
		assertEquals(sum, testSum);
	}

}