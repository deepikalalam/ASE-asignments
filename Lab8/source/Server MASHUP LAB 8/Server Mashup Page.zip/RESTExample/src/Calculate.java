public class Calculate {

	public int sum(int var1) {
		
		int Area;
		
		Area = (int) (2 * 3.14 * var1);
		System.out.println("Area of circle " +Area);
		return Area;
	}

}